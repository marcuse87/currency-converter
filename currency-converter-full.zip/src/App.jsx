import React, { useState, useEffect } from 'react';

const App = () => {
  const [amount, setAmount] = useState(1);
  const [fromCurrency, setFromCurrency] = useState("USD");
  const [toCurrency, setToCurrency] = useState("EUR");
  const [result, setResult] = useState(null);
  const [rates, setRates] = useState({});

  useEffect(() => {
    fetch(`https://api.exchangerate.host/latest?base=${fromCurrency}`)
      .then(res => res.json())
      .then(data => setRates(data.rates));
  }, [fromCurrency]);

  useEffect(() => {
    if (rates[toCurrency]) {
      setResult((amount * rates[toCurrency]).toFixed(2));
    }
  }, [rates, toCurrency, amount]);

  return (
    <div style={{ padding: '2rem', maxWidth: '500px', margin: 'auto' }}>
      <h1>Currency Converter</h1>
      <div style={{ marginBottom: '1rem' }}>
        <input
          type="number"
          value={amount}
          onChange={e => setAmount(e.target.value)}
          style={{ width: '100%', padding: '0.5rem', fontSize: '1rem' }}
        />
      </div>
      <div style={{ display: 'flex', gap: '1rem', marginBottom: '1rem' }}>
        <select value={fromCurrency} onChange={e => setFromCurrency(e.target.value)}>
          {Object.keys(rates).map(code => (
            <option key={code} value={code}>{code}</option>
          ))}
        </select>
        <span style={{ alignSelf: 'center' }}>to</span>
        <select value={toCurrency} onChange={e => setToCurrency(e.target.value)}>
          {Object.keys(rates).map(code => (
            <option key={code} value={code}>{code}</option>
          ))}
        </select>
      </div>
      <h2>
        {amount} {fromCurrency} = {result} {toCurrency}
      </h2>
    </div>
  );
};

export default App;